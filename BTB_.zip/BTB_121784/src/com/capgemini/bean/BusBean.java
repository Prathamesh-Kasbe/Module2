package com.capgemini.bean;

import java.sql.Date;

public class BusBean {
private int busId;
private String busType;
private Date dateOfJourney;
private String fromStop;
private String toStop;
private int availableSeats;
private int fare;

public BusBean() {
	super();
}

public BusBean(int busId, String busType, Date dateOfJourney,
		String fromStop, String toStop, int availableSeats, int fare) {
	super();
	this.busId = busId;
	this.busType = busType;
	this.dateOfJourney = dateOfJourney;
	this.fromStop = fromStop;
	this.toStop = toStop;
	this.availableSeats = availableSeats;
	this.fare = fare;
}

public int getBusId() {
	return busId;
}

public String getBusType() {
	return busType;
}

public Date getDateOfJourney() {
	return dateOfJourney;
}

public String getFromStop() {
	return fromStop;
}

public String getToStop() {
	return toStop;
}

public int getAvailableSeats() {
	return availableSeats;
}

public int getFare() {
	return fare;
}

public void setBusId(int busId) {
	this.busId = busId;
}

public void setBusType(String busType) {
	this.busType = busType;
}

public void setDateOfJourney(Date dateOfJourney) {
	this.dateOfJourney = dateOfJourney;
}

public void setFromStop(String fromStop) {
	this.fromStop = fromStop;
}

public void setToStop(String toStop) {
	this.toStop = toStop;
}

public void setAvailableSeats(int availableSeats) {
	this.availableSeats = availableSeats;
}

public void setFare(int fare) {
	this.fare = fare;
}

@Override
public String toString() {
	return "BusBean [busId=" + busId + ", busType=" + busType
			+ ", dateOfJourney=" + dateOfJourney + ", fromStop=" + fromStop
			+ ", toStop=" + toStop + ", availableSeats=" + availableSeats
			+ ", fare=" + fare + "]"+"\n";
}


}
