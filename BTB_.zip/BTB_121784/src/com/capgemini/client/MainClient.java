package com.capgemini.client;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.service.BusService;
import com.capgemini.service.BusServiceImpl;



public class MainClient {
	private static final Logger myLogger=Logger.getLogger(MainClient.class);
	
	
	public static void main(String[] args) {
		
		
		
		boolean b;
      int choice=0;
        BusService busService=new BusServiceImpl();
        BookingBean bookingBean=new BookingBean();
        BusBean busBean=new BusBean();
		do{
			printMenu();
		Scanner scr=new Scanner(System.in);
		myLogger.info("Application started");
		System.out.println("Enter the choice");
		choice=scr.nextInt();
		switch(choice){
		case 1:
		
			try{
			   System.out.println(busService.retrieveBusDetails());
				
				Scanner sc=new Scanner(System.in);
				do{
				
				System.out.println("Enter the customer Id");
				String custId=sc.next();
				bookingBean.setCustId(custId);
				String patt="[A-Z][0-9]{6}";
				Pattern pattern=Pattern.compile(patt);
				Matcher matcher=pattern.matcher(custId);
				b=matcher.matches();
				if(!b){
					System.out.println("Enter the correct customer id");
				}
				}while(b!=true);
				
				int noOfSeat=0;
				
				do{
					
					System.out.println("Enter the bus Id from the above table");
					int busId=sc.nextInt();
					bookingBean.setBusId(busId);
					
					System.out.println("Enter the number of seats to be booked");
					noOfSeat=sc.nextInt();
					bookingBean.setNoOfSeat(noOfSeat);
					if(noOfSeat>0 && noOfSeat<busService.checkAvailabeSeats(busId)){
						System.out.println("Thank You. Your booking id is "+busService.bookTicket(bookingBean));
					break;	
					}
					else{
						System.out.println("Sorry No Seats available");
					}
				}while(true);
					
					
				
			}catch(BookingException book){
				System.out.println(book);
			}
			
		case 2:
		myLogger.info("Application closed");
			break;
		}
		

	}while(choice<2);
	}
		public static void printMenu(){
			System.out.println("***********");
			System.out.println("1. Book Ticket");
			System.out.println("2. Exit");
			System.out.println("***********");
		}

}
