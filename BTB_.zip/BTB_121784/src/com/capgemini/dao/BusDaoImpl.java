package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.exception.BookingException;
import com.capgemini.util.JdbcUtil;
;

public class BusDaoImpl implements BusDao{

	BookingBean bookingBean=new BookingBean();
	BusBean busBean=new BusBean();
	Connection con;
	PreparedStatement pst;
	private static final Logger myLogger=Logger.getLogger(BusBean.class);
	
	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		con=JdbcUtil.getConnection();                      
		String query="SELECT * FROM BusDetails";              
		ArrayList<BusBean> mList=new ArrayList<BusBean>();
		try {
			pst=con.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next()){
				int b_id=rs.getInt(1); 
				String bus_type=rs.getString(2);  
				String fromStop=rs.getString(3);
				String toStop=rs.getString(4);
				int fare=rs.getInt(5);
				int seat=rs.getInt(6);
				Date time=rs.getDate(7);
				Date dateOfJourney=time;
							
				BusBean busBean=new BusBean();
				busBean.setBusId(b_id);
				busBean.setBusType(bus_type);
				busBean.setDateOfJourney(dateOfJourney);
				busBean.setFromStop(fromStop);
				busBean.setToStop(toStop);
				busBean.setAvailableSeats(seat);
				busBean.setFare(fare);
				mList.add(busBean);
				
			}
			myLogger.info("Data found");
		}catch(SQLException e){
			myLogger.error("Data not Found");
			System.out.println(e);
			throw new BookingException("No data available in the database");
		}finally{
			try{
			    con.close();
				pst.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
			
		}
		return mList;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		
		
		con=JdbcUtil.getConnection();  
		BusDao busDao=new BusDaoImpl();
		int bookingId=busDao.generateBookingId();
		bookingBean.setBookingId(bookingId);
		String query="INSERT INTO BOOKINGDETAILS VALUES(?,?,?,?)";   
		try{
			pst=con.prepareStatement(query);
			pst.setInt(1,bookingBean.getBookingId());
			pst.setString(2,bookingBean.getCustId());
			pst.setInt(3,bookingBean.getBusId());
			pst.setInt(4,bookingBean.getNoOfSeat());
			int rec=pst.executeUpdate();
			busDao.updateSeats(bookingBean.getBusId(),bookingBean.getNoOfSeat());
		myLogger.info("Ticket booked successfully");
	}catch(SQLException e){
		myLogger.error("Ticket not booked");
		System.out.println(e);
		throw new BookingException("Failed to book the ticket");
	}finally{
		try{
		    con.close();
			pst.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		
	}
		return bookingId;
	}

	public int generateBookingId() throws BookingException{
		con=JdbcUtil.getConnection();                      
		String query="SELECT BOOKING_ID_SEQ.NEXTVAL FROM BOOKINGDETAILS"; 
		int bookingId=0;
		try{
			pst=con.prepareStatement(query);
			  ResultSet rs=pst.executeQuery();
			    while(rs.next()){
				bookingId=rs.getInt(1); 
			}
		
           }catch(SQLException e){
	      myLogger.error("BookingId not generated");
	      System.out.println(e);
	      throw new BookingException("Failed to generate booking id");
             }finally{
	try{
	    con.close();
		pst.close();
	}catch(SQLException e){
		e.printStackTrace();
	}
	
}
	return bookingId;
}
	
	

	@Override
	public int checkAvailabeSeats(int busId) throws BookingException {
		con=JdbcUtil.getConnection(); 
		String query=null;
		
		query="SELECT AVAILABLESEATS FROM BUSDETAILS WHERE BUSID=?";
		
		int availableSeats=0;
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1,busId);
		ResultSet res=pst.executeQuery();
		while(res.next()){
		availableSeats=res.getInt("availableSeats");
		}
		
			
		
		myLogger.info("Quantity updated successfully");
		}catch (SQLException e) {
			myLogger.error("Failed to update quantity");
			e.printStackTrace();
			throw new BookingException("Data not Updated");
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return availableSeats;
	}
@Override
	public int updateSeats(int busId,int noOfSeats) throws BookingException {
		con=JdbcUtil.getConnection(); 
		String query=null;
		
		query="UPDATE BUSDETAILS SET AVAILABLESEATS=AVAILABLESEATS-? WHERE BUSID=?";
		
		int availableSeats=0;
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1,noOfSeats);
			pst.setInt(2,busId);
		int rec=pst.executeUpdate();
		/*System.out.println("Seats updated");*/
		
			
		
		myLogger.info("seats updated successfully");
		}catch (SQLException e) {
			myLogger.error("Failed to update seats");
			e.printStackTrace();
			throw new BookingException("Data not Updated");
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return availableSeats;
	}
	
}