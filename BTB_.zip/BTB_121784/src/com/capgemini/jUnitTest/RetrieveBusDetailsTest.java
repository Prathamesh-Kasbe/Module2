package com.capgemini.jUnitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class RetrieveBusDetailsTest {
BusDao busDao;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		busDao=new BusDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		busDao=null;
	}

	@Test
	public void testRetrieveBusDetails() throws BookingException {
		assertNotNull(busDao.retrieveBusDetails());
	}

}
