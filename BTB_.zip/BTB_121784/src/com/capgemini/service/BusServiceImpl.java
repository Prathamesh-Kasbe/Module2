package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDao;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.exception.BookingException;

public class BusServiceImpl implements BusService{

	BusDao busDao=new BusDaoImpl();
	
	@Override
	public ArrayList<BusBean> retrieveBusDetails()throws BookingException {
		
		return busDao.retrieveBusDetails();
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		
		return busDao.bookTicket(bookingBean);
	}

	

	@Override
	public int checkAvailabeSeats(int busId)throws BookingException {
		
		return busDao.checkAvailabeSeats(busId);
	}

	@Override
	public int generateBookingId() throws BookingException {
		return busDao.generateBookingId();
	}

	@Override
	public int updateSeats(int busId, int noOfSeats) throws BookingException {
		// TODO Auto-generated method stub
		return updateSeats(busId,noOfSeats);
	}

}
